import pandas as pd
from fhir.resources.observation import Observation
from fhir.resources.fhirdate import FHIRDate
from datetime import datetime

# Load CSV data into a pandas DataFrame
df = pd.read_csv('heart_rate_data.csv', parse_dates=['timestamp'])

# Convert DataFrame rows to FHIR Observation resources
observations = []
for index, row in df.iterrows():
    observation = Observation()

    # Setting effective date time
    effective_date_time = FHIRDate(datetime.strptime(row['timestamp'], '%Y-%m-%d %H:%M:%S.%f'))

    # Setting observation values
    observation.status = "final"
    observation.category = [{"coding":[{"system":"http://terminology.hl7.org/CodeSystem/observation-category","code":"vital-signs","display":"Vital Signs"}]}]
    observation.code = {"coding":[{"system":"http://loinc.org","code":"8867-4","display":"Heart Rate"}]}
    observation.subject.reference = "Patient/123"
    observation.effectiveDateTime = effective_date_time
    observation.valueQuantity = {'value': row['heart_rate'], 'unit': 'bpm', 'system': 'http://unitsofmeasure.org', 'code': 'bpm'}

    observations.append(observation)

# Output FHIR resources as JSON
fhir_json = [obs.as_json() for obs in observations]

# Write JSON to file or do something else with it
with open('heart_rate_fhir.json', 'w') as f:
    f.write('\n'.join([json.dumps(obs, indent=2) for obs in fhir_json]))

print(f"Successfully converted heart rate data to FHIR JSON. Output saved to 'heart_rate_fhir.json'.")
